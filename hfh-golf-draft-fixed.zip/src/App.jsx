export default function App() {
  return (
    <div className="app-container">
      <h1>HFH Golf Draft</h1>
      <p>Welcome. Everything is working as expected 🎯</p>
    </div>
  );
}
